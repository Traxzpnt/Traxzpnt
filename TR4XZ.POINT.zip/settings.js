require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6285143934867"
global.namaowner = "JeloolHost"

//======== Setting Bot & Link ========//
global.namabot = "TRAXZ.POINT" 
global.idsaluran = "TRAXZ.POINT"
global.linkgc = '_'
global.packname = "BOT TRAXZ.POINT ANTI KENON✨"
global.author = "TRAXZ.POINT"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 1000
global.delayjpm = 5500

//========= Setting Url Foto =========//
global.image = "https://img86.pixhost.to/images/524/563582484_uploaded_image.jpg"

//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.domain = "https://rapziedevsrvpublic.zakzz.my.id"
global.apikey = "ptla_gIPfXvN69PkYxcR0hOuWxboAuOukW29UGqyYUEqpe0I"
global.capikey = "ptlc_tkEyLfgfADAdZagT6bMMNi6GWfXIK8dvgiVInOEF4xH"

//========= Setting Payment =========//
global.dana = "081278801461"
global.gopay = ""
global.ovo = false
global.qris = "Minta Ajah Ke Bang TRAXZ.POINT"


//=========== Api Domain ===========//
global.zone1 = "-";
global.apitoken1 = "-";
global.tld1 = "-";
//========== Api Domain 2 ==========//
global.zone2 = "a476ffcf9243c44a02220f184da527e8";
global.apitoken2 = "RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ";
global.tld2 = "mypanell.biz.id";
//========== Api Domain 3 ==========//
global.zone3 = "5f4a582dd80c518fb2c7a425256fb491";
global.apitoken3 = "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby";
global.tld3 = "tokopanellku.my.id";
//========== Api Domain 4 ==========//
global.zone4 = "d41a17e101c0f89f0aec609c31137f91";
global.apitoken4 = "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi";
global.tld4 = "panellstore.net";

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Berhasil mengambil data ✅", 
"wait": "✅Proses bang TRAXZ.POINT....🗿🚬", 
"group": "Fitur Ini Hanya Untuk Didalam Grup❗", 
"private": "Fitur Ini Hanya Untuk Didalam Private Chat❗", 
"admin": "Fitur Ini Hanya Untuk Admin Grup❗", 
"adminbot": "Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin❗", 
"owner": "Fitur Ini Hanya Untuk Owner Bot❗", 
"developer": "Fitur Ini Hanya Untuk Developer❗"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})